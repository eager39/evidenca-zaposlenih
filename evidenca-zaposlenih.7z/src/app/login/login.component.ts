import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor( 
    private auth: AuthService
    
    ) { }

    login = new FormGroup({
      username: new FormControl(''),
      password: new FormControl(''),
    });

  ngOnInit() {
    
  }
  onSubmit(){
    var logindata=this.login.value;
    this.auth.login(logindata);
  }
 

}
